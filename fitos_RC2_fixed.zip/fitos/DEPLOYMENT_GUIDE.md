# FitOS — Deployment Guide

## Prerequisites

- Firebase project configured (see `FIRESTORE_SETUP.md`)
- Authentication + Firestore enabled
- Security Rules deployed
- `firebase-init.js` updated with your project config

---

## Option A — Firebase Hosting (Recommended)

### Install Firebase CLI
```bash
npm install -g firebase-tools
firebase login
```

### Initialise Firebase Hosting
```bash
cd fitos/
firebase init hosting
```

When prompted:
- **What do you want to use as your public directory?** → `.` (current directory)
- **Configure as a single-page app?** → `No`
- **Set up automatic builds with GitHub?** → Optional

### Deploy
```bash
firebase deploy --only hosting
```

Your app will be live at `https://YOUR_PROJECT.web.app`

---

## Option B — Netlify

1. Go to [https://app.netlify.com](https://app.netlify.com) → **Add new site** → **Deploy manually**
2. Drag and drop the `fitos/` folder into the deploy dropzone
3. Done — Netlify assigns a `*.netlify.app` URL immediately

### Custom Domain on Netlify
1. **Site settings** → **Domain management** → **Add custom domain**
2. Add your domain → update DNS CNAME/A records as instructed
3. SSL certificate auto-provisioned

---

## Option C — Vercel

```bash
npm install -g vercel
cd fitos/
vercel --prod
```

Follow the prompts. Vercel auto-detects static HTML.

---

## Option D — Any Static Host (GitHub Pages, Cloudflare Pages, S3, etc.)

FitOS is a pure static site. Upload all files from the `fitos/` directory to any host that serves static HTML.

**Requirements:**
- HTTPS must be enabled (required by Firebase Auth)
- All files must be in the same directory (no subdirectory nesting required)
- No server-side configuration needed

---

## Post-Deployment Checklist

After deploying to your final domain:

1. **Add domain to Firebase Auth**
   - Firebase Console → Authentication → Settings → Authorized domains → Add your domain

2. **Verify Google OAuth works** (if enabled)
   - Try signing in with Google on your deployed URL
   - If it fails, the domain is not in the Authorized domains list

3. **Verify Firestore writes**
   - Sign up → complete onboarding → check Firebase Console for `profiles/{uid}`

4. **Test on mobile**
   - iOS Safari and Android Chrome
   - Verify bottom nav, safe area insets, and touch targets

5. **Test in incognito**
   - Verifies no stale session/cache issues

---

## Environment Notes

FitOS uses **no build step** and **no environment variables**. All configuration is in `firebase-init.js`.

Firebase API keys in client-side code are intentional and safe — they are restricted by Firestore Security Rules and Firebase Auth domain restrictions, not by key secrecy.

