# FitOS — Intelligent Fitness Platform

**Version**: 1.0.0-RC1 | **Status**: Production Ready

FitOS is a fully responsive fitness web application built with HTML, CSS, and Vanilla JavaScript, powered by Firebase Authentication and Cloud Firestore. No frameworks. No build step.

---

## Features

| Module | Description |
|--------|-------------|
| 🏠 **Landing Page** | Marketing site with hero, features, comparison, FAQ |
| 🔐 **Authentication** | Email/password + Google OAuth sign-in |
| 🎯 **Onboarding** | 13-step personalisation wizard |
| 📊 **Dashboard** | Personalised overview with live metrics |
| 💪 **Workout Plans** | AI-generated 4-split plans based on goal/level/equipment |
| ⏱️ **Guided Sessions** | Set tracking, rest timer, exercise info |
| 🥗 **Nutrition** | 160+ food database, custom entry, macro tracking |
| 🧠 **AI Coach** | Decision-tree coach with 20+ pathways |
| 🔄 **Recovery** | Daily check-in with 4-factor readiness score |
| 📈 **Progress** | Charts for weight, volume, readiness, calories |
| 👤 **Profile** | Full edit with plan regeneration |
| ⚙️ **Settings** | Theme, nutrition targets, units |
| 📤 **Export** | JSON + CSV data export |
| 📝 **Contact** | Firestore-backed support form |

---

## Tech Stack

- **Frontend**: HTML5, CSS3, Vanilla JavaScript (ES2020+)
- **Auth**: Firebase Authentication (Email + Google)
- **Database**: Cloud Firestore
- **Charts**: Chart.js 4
- **Icons**: SVG (inline, no icon font dependency)
- **Fonts**: Google Fonts — Inter

---

## Getting Started

### 1. Configure Firebase
See [`FIRESTORE_SETUP.md`](FIRESTORE_SETUP.md) for full instructions.

Update `firebase-init.js` with your Firebase project config:
```javascript
const firebaseConfig = {
  apiKey: "...",
  authDomain: "...",
  projectId: "...",
  ...
};
```

### 2. Deploy
See [`DEPLOYMENT_GUIDE.md`](DEPLOYMENT_GUIDE.md) for full instructions.

Quickest option:
```bash
npm install -g firebase-tools
firebase login
firebase init hosting    # public dir = "."
firebase deploy
```

### 3. First Run
- Visit your deployed URL
- Click **Start Free** to create an account
- Complete the 13-step onboarding
- Your first workout plan is generated automatically

---

## File Structure

```
fitos/
├── index.html              Landing page
├── login.html              Sign in
├── signup.html             Create account
├── onboarding.html         13-step setup wizard
├── dashboard.html          Home dashboard
├── workouts.html           Workout plan overview
├── workout-current.html    Guided workout session
├── workout-history.html    Past sessions
├── nutrition.html          Today's nutrition
├── nutrition-log.html      Food logging
├── nutrition-history.html  Past logs
├── coach.html              AI Coach center
├── recovery.html           Recovery check-in
├── progress.html           Charts & analytics
├── profile.html            Edit profile
├── settings.html           App settings
├── account.html            Account management
├── export.html             Data export
├── contact.html            Support form
├── privacy.html            Privacy policy
├── terms.html              Terms of service
├── styles.css              Global design system
├── firebase-init.js        Firebase SDK + shared utilities
├── nav.js                  Navigation config
├── foods.js                Food database (160+ items)
├── coach-tree.js           Coach decision tree data
├── README.md               This file
├── CHANGELOG.md            Version history
├── PROJECT_STATUS.md       Module status tracker
├── FIRESTORE_SETUP.md      Firebase configuration guide
├── DEPLOYMENT_GUIDE.md     Hosting instructions
├── QA_REPORT.md            Quality assurance report
├── REGRESSION_TESTING.md   Test results
└── RELEASE_NOTES.md        RC1 release notes
```

---

## Documentation

| Document | Purpose |
|----------|---------|
| [`CHANGELOG.md`](CHANGELOG.md) | All changes in RC1 |
| [`PROJECT_STATUS.md`](PROJECT_STATUS.md) | Module completion status |
| [`QA_REPORT.md`](QA_REPORT.md) | Full QA audit results |
| [`REGRESSION_TESTING.md`](REGRESSION_TESTING.md) | End-to-end test results |
| [`RELEASE_NOTES.md`](RELEASE_NOTES.md) | What's new and deployment checklist |
| [`FIRESTORE_SETUP.md`](FIRESTORE_SETUP.md) | Firebase configuration |
| [`DEPLOYMENT_GUIDE.md`](DEPLOYMENT_GUIDE.md) | Hosting and deployment |

---

## License

© 2026 FitOS. All rights reserved.

