# FitOS — Firestore Setup Guide

## 1. Create Firebase Project

1. Go to [https://console.firebase.google.com](https://console.firebase.google.com)
2. Click **Add project** → name it `fitos` (or your preferred name)
3. Enable Google Analytics (optional but recommended)
4. Click **Create project**

---

## 2. Enable Authentication

1. In Firebase Console → **Authentication** → **Get started**
2. Enable **Email/Password** provider
3. Enable **Google** provider → add your support email
4. Under **Settings** → **Authorized domains** → add your deployment domain (e.g. `your-app.web.app` or your custom domain)

---

## 3. Create Firestore Database

1. Firebase Console → **Firestore Database** → **Create database**
2. Choose **Start in production mode** (you will add rules next)
3. Select your nearest region (e.g. `us-central`, `europe-west`)

---

## 4. Deploy Security Rules

In Firebase Console → **Firestore Database** → **Rules**, paste:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Profiles — each user owns their own document
    match /profiles/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;

      // Subcollections under profiles
      match /{subcollection}/{docId} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }

    // Contact messages — authenticated users can write, nobody can read via client
    match /contact_messages/{docId} {
      allow create: if request.auth != null;
      allow read, update, delete: if false;
    }
  }
}
```

Click **Publish**.

---

## 5. Update `firebase-init.js`

Replace the Firebase config object in `firebase-init.js` with your project's config:

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
  measurementId: "G-XXXXXXXXXX"   // optional, for Analytics
};
```

Find your config at: Firebase Console → Project Settings → Your apps → Web app.

---

## 6. Firestore Collections (Auto-Created)

FitOS creates these collections automatically on first use:

| Collection | Document ID Pattern | Description |
|------------|-------------------|-------------|
| `profiles` | `{uid}` | User profile, settings, workout plan |
| `profiles/{uid}/workout_logs` | `{uid}_{date}_{dayName}` | Individual workout sessions |
| `profiles/{uid}/nutrition_logs` | `{uid}_{date}_{mealType}_{timestamp}` | Food log entries |
| `profiles/{uid}/assessments` | `{uid}_{date}_{type}` | Recovery check-ins, weight logs |
| `profiles/{uid}/coach_history` | `{uid}_coach` | Coach conversation state |
| `contact_messages` | Auto-ID | Support submissions |

---

## 7. Enable Firestore Indexes (if needed)

FitOS queries use simple single-field filters with `orderBy`. Composite indexes are not required for the current query patterns.

If you see index errors in the console, follow the link in the error message to auto-create the index.

---

## 8. Optional: Enable Firebase Analytics

1. Firebase Console → **Analytics** → Enable
2. Your `measurementId` will appear in the web app config
3. Analytics events are fired automatically via the Firebase SDK

