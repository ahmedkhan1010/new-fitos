# FitOS v1.0.0-RC1 — Final Release Notes

**Release Date**: 2026-06-27  
**Type**: Production Release Candidate  
**Status**: ✅ Ready for Deployment

---

## What Is FitOS?

FitOS is a fully responsive, AI-assisted fitness platform built with HTML, CSS, and Vanilla JavaScript, backed by Firebase Authentication and Cloud Firestore.

It covers the complete fitness journey:
- Personalised workout plan generation
- Guided workout sessions with rest timers
- Nutrition tracking with 160+ foods
- Daily recovery check-ins and readiness scoring
- AI Coach decision tree with 20+ pathways
- Progress charts for weight, volume, readiness, and calories
- Data export (JSON/CSV)

---

## What's New in RC1

### Production Hardening
- XSS protection added to all Firestore-sourced `innerHTML` content via shared `esc()` utility
- Input validation added to Profile (name required, numeric ranges enforced)
- Activity factor in Nutrition Goals now uses the user's actual lifestyle setting from their profile
- Missing `firebase-firestore-compat.js` on Contact page fixed (submissions now actually save)

### UX Improvements
- Dashboard greeting now personalised: "Good morning, Alex 👋"
- Recovery check-in form pre-populates if you've already checked in today
- Workout session remembers your selected training day during a session
- Progress weight modal validates input range and shows a loading state

### Accessibility
- Keyboard navigation for all settings toggles (Space/Enter)
- ARIA roles and `aria-checked` on all toggle switches
- Hamburger menu has accessible label and `aria-expanded` state
- Removed CSS rule that was stripping focus outlines from interactive elements

### Code Quality
- Shared `calcStreak()` and `getWeekOfYear()` utilities in `firebase-init.js`; removed duplicates
- Removed duplicate `pct()` from `workout-current.html`
- Eliminated ~50 lines of duplicate CSS rules
- Correct nav highlighting on Export and Account pages

---

## Upgrade Notes

This is a fresh deployment. No database migration required.

If updating from a prior development build:
1. Replace all project files with this RC1 build
2. Firestore Security Rules do not need updating
3. Existing user data is fully compatible

---

## Deployment Checklist

- [ ] Firebase project configured (see `FIRESTORE_SETUP.md`)
- [ ] Google OAuth domain added to Firebase Authorized Domains
- [ ] Firestore Security Rules deployed
- [ ] Hosting configured (Firebase Hosting, Netlify, Vercel, or any static host)
- [ ] HTTPS enforced (required for Firebase Auth)
- [ ] Test Sign Up, Login, Onboarding, and Workout flows on production

---

## Known Non-Issues

The following are intentional design decisions, not bugs:

- **No service worker / PWA**: App is fully functional as a website; no offline-first requirement
- **No server-side rendering**: All auth/data handled client-side via Firebase SDK
- **Charts don't live-update on theme change**: Require page reload — acceptable trade-off
- **Password change via email reset**: Firebase limitation; re-authentication required for sensitive actions

