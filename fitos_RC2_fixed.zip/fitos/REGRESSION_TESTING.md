# FitOS — Regression Testing Report

**Version**: 1.0.0-RC1  
**Date**: 2026-06-27

---

## Regression Tests — Core Flows

All tests verified against RC1 build.

### Authentication

| Test | Expected | Result |
|------|----------|--------|
| Sign up with valid email/password | Account created, routed to onboarding | ✅ Pass |
| Sign up with existing email | "Email already in use" error shown | ✅ Pass |
| Sign up with password < 6 chars | "Password too short" error shown | ✅ Pass |
| Login with correct credentials | Routed to dashboard | ✅ Pass |
| Login with wrong password | "Invalid credentials" error shown | ✅ Pass |
| Password reset flow | Reset email dispatched, confirmation shown | ✅ Pass |
| Google sign-in popup | Auth completes, profile seeded | ✅ Pass |
| Accessing protected page while logged out | Redirected to login.html | ✅ Pass |
| Logout | Session cleared, redirected to login | ✅ Pass |

### Onboarding

| Test | Expected | Result |
|------|----------|--------|
| Complete all 13 steps | Plan generated, routed to dashboard | ✅ Pass |
| Skip to next step without selecting chip | Toast error, no progress | ✅ Pass |
| Enter age below 14 | "Minimum value is 14" error | ✅ Pass |
| Enter age above 80 | "Maximum value is 80" error | ✅ Pass |
| Already onboarded user visits /onboarding | Redirected to dashboard | ✅ Pass |
| Back button within onboarding | Returns to previous step | ✅ Pass |

### Workout Session

| Test | Expected | Result |
|------|----------|--------|
| Load workout-current with no plan | Empty state with link to onboarding | ✅ Pass |
| Switch training day | Day tabs update, exercises reload | ✅ Pass |
| Day selection persists on refresh | Same day shown on reload | ✅ Pass |
| Complete a set | Set checked, progress updated | ✅ Pass |
| Rest timer starts after set | Countdown begins, vibrates on end | ✅ Pass |
| Skip rest timer | Timer dismissed, next set ready | ✅ Pass |
| Finish workout with 0 sets | Toast warning, not saved | ✅ Pass |
| Finish workout with sets done | Saved to Firestore, modal shown | ✅ Pass |
| After finish, day cleared from sessionStorage | Fresh day selection on next visit | ✅ Pass |
| Navigate to dashboard from finish modal | Dashboard loads with new workout in recent list | ✅ Pass |

### Nutrition

| Test | Expected | Result |
|------|----------|--------|
| Nutrition page with no logs | Empty state shown | ✅ Pass |
| Search for a food | Filtered results appear | ✅ Pass |
| Add food to log | Appears in today's log, macros update | ✅ Pass |
| Delete food from log | Removed from list and Firestore | ✅ Pass |
| Custom food entry | Saves with correct macros | ✅ Pass |
| Calorie goal respects lifestyle | Sedentary user gets lower goal than Very Active | ✅ Pass |
| View history by date | Correct day's logs shown | ✅ Pass |

### Profile & Settings

| Test | Expected | Result |
|------|----------|--------|
| Save profile with empty name | "Name is required" error, no save | ✅ Pass |
| Save profile with age 9999 | "Maximum value is 100" error | ✅ Pass |
| Save profile with weight -5 | "Minimum value is 20" error | ✅ Pass |
| Save valid profile | Saved to Firestore, success toast | ✅ Pass |
| Change equipment triggers plan regen prompt | Confirm dialog appears | ✅ Pass |
| Toggle dark mode | Theme applied immediately, persisted | ✅ Pass |
| Toggle dark mode with keyboard (Space) | Same as click | ✅ Pass |

### Recovery

| Test | Expected | Result |
|------|----------|--------|
| First check-in of the day | Form empty, save creates new record | ✅ Pass |
| Revisit check-in page same day | Form pre-populated with existing values | ✅ Pass |
| Update existing check-in | Upserts in Firestore, success toast | ✅ Pass |
| Readiness score calculation | Correct weighted average shown | ✅ Pass |
| History renders last 30 days | Correct records in order | ✅ Pass |

### Progress Charts

| Test | Expected | Result |
|------|----------|--------|
| Weight chart with no data | Empty state or flat line | ✅ Pass |
| Weight chart in light mode | Grid/tick colors are light-appropriate | ✅ Pass |
| Weight chart in dark mode | Grid/tick colors are dark-appropriate | ✅ Pass |
| Log weight via modal | Chart re-renders after save | ✅ Pass |
| Weight outside 20–350 range | Validation error, not saved | ✅ Pass |

### Coach Center

| Test | Expected | Result |
|------|----------|--------|
| Start coach conversation | Opening question rendered | ✅ Pass |
| Navigate through decision tree | Options render, pathway followed | ✅ Pass |
| Reach a terminal advice node | Full advice card shown | ✅ Pass |
| Restart conversation | Returns to initial state | ✅ Pass |
| Chat saved to Firestore | History visible on return visit | ✅ Pass |

### Export

| Test | Expected | Result |
|------|----------|--------|
| Export workouts as JSON | Valid JSON file downloaded | ✅ Pass |
| Export workouts as CSV | Valid CSV file downloaded | ✅ Pass |
| Export nutrition as JSON | Valid JSON file downloaded | ✅ Pass |
| Export nutrition as CSV | Valid CSV file downloaded | ✅ Pass |

### Contact / Support

| Test | Expected | Result |
|------|----------|--------|
| Submit form without name | Validation prevents submit | ✅ Pass |
| Submit form without email | Validation prevents submit | ✅ Pass |
| Submit form with invalid email | Validation error shown | ✅ Pass |
| Submit valid form | Saved to Firestore, success message shown | ✅ Pass |

---

## Regression Tests — Cross-Cutting Concerns

| Test | Expected | Result |
|------|----------|--------|
| Dark mode persists across page navigations | Theme loaded from Firestore/localStorage | ✅ Pass |
| Bottom nav highlights correct page | Active page highlighted | ✅ Pass |
| Sidebar nav highlights correct page | Active page highlighted | ✅ Pass |
| Hamburger shows sidebar on mobile | Sidebar slides in | ✅ Pass |
| Click outside sidebar closes it | Sidebar closes | ✅ Pass |
| Toast messages appear and auto-dismiss | 3-second auto-dismiss | ✅ Pass |
| Modal dismisses on overlay click | Modal closes | ✅ Pass |
| All loading screens hide after auth check | Page renders within 1–2s | ✅ Pass |
| Firestore offline (airplane mode) | Last cached data shown, no crash | ✅ Pass |

