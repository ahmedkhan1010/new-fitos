# FitOS Changelog

## v1.0.0-RC1 — Production Release Candidate (2026-06-27)

### Security Fixes
- Added `esc()` HTML escaping utility to `firebase-init.js` for XSS prevention across all Firestore-sourced `innerHTML` template literals (workout names, food names, session notes)
- Removed `foods.js` (~34KB) from `contact.html` where it was unnecessarily loaded
- Removed `color:#000` on account avatar (was invisible against dark gradient) — changed to `#fff`
- Fixed duplicate `style=""` attribute on contact success message element (second one was silently ignored)

### Bug Fixes
- **Dashboard**: Greeting now shows user's first name (e.g. "Good morning, Alex 👋")
- **Dashboard**: Calorie goal shows "/ — goal" while loading instead of "/ 0 goal"
- **Recovery**: Form now pre-populates with today's existing check-in values when user revisits; save button reads "Update Check-In →" if data already exists
- **Recovery**: Added `setRatingBtn()` helper to correctly restore button active states
- **Profile**: Added input validation (name required, age 13–100, weight 20–350 kg, height 100–250 cm) before saving
- **Profile**: Save now uses pre-validated variables instead of re-reading DOM values
- **Workout Current**: Selected training day now persists in `sessionStorage` during a session; cleared on Finish
- **Workout Current**: Removed local `pct()` duplicate — now uses shared version from `firebase-init.js`
- **Workout History**: Fixed month grouping to use `toTimeValue()` for reliable timestamp resolution across Firestore Timestamp and ISO string formats
- **Progress**: Weight input now has `min="20" max="350"` HTML validation
- **Progress**: Save weight button shows loading state and re-enables on error
- **Settings**: Theme toggle now properly updates `aria-checked` attribute
- **Settings**: All toggles support keyboard activation (Space/Enter keys)
- **Export**: `buildNav('export.html')` — was incorrectly highlighting Settings in nav
- **Account**: `buildNav('account.html')` — was incorrectly highlighting Settings in nav
- **Navigation**: `buildNav()` now toggles `aria-expanded` on the hamburger button
- **Onboarding**: Number input validation now checks min/max range per step (age 14–80, height 100–250)
- **Nutrition**: Activity factor now correctly uses `profile.lifestyle` field (was hardcoded to `1.375` for everyone)
- **Contact**: Missing `firebase-firestore-compat.js` script added (caused `db is not defined` error on form submit)

### Performance Improvements
- **CSS**: Removed ~50 lines of duplicate CSS from appended "Animation & UX Upgrade (v3)" block:
  - Duplicate `@keyframes`: `fadeIn`, `scaleIn`, `pulse`, `bounceIn`, `glow`, `spin`
  - Duplicate `.loading-screen` / `.spinner` definitions
  - Duplicate `.modal-overlay` / `.modal` animation rules
  - Duplicate `.toast` animation rules
  - Duplicate `@media (prefers-reduced-motion)` block
- **CSS**: Removed global `-webkit-touch-callout: none` (was disabling iOS long-press context menus on text)
- **CSS**: Removed `button:focus, a:focus { outline: none }` override that broke keyboard accessibility
- **JavaScript**: `calcStreak()` and `getWeekOfYear()` moved to `firebase-init.js` as shared utilities — removed page-level duplicates in `dashboard.html` and `workouts.html`
- **CSS**: `badge-green` now correctly displays green (was accidentally using brand purple)

### Accessibility Improvements
- All hamburger menu buttons now have `aria-label="Open navigation menu"` and `aria-expanded` state
- Settings toggles now have `role="switch"`, `aria-checked`, and keyboard (Space/Enter) support
- Progress charts now generate theme-aware colors (respects light/dark mode)
- All `@media (prefers-reduced-motion)` rules now correctly use `0.001ms` (not `.01ms`)

### UX Polish
- Badge-green displays actual green color in both light and dark modes
- Dark mode chart grid/tick colors now auto-detect theme via `buildChartOptions()`

